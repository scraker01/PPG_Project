import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('saveAndLoad')
export class saveAndLoad extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}


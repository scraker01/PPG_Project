import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('levelController')
export class levelController extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}


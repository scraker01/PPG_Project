import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('BulletModel')
export class BulletModel extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}


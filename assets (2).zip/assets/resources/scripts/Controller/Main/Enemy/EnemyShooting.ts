import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('EnemyShooting')
export class EnemyShooting extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}

